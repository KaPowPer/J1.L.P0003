package Utils;

import DTO.Product;
import DTO.Category;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Scanner;

public class PValid {
    private static final String NUMBER = "^[0-9]$";
    private static final String ID = "^[0-9]{3}$";
    private static final String NAME = "^[a-zA-Z!~@#$%&*()<>-]+$";
    private static final String PRICE = "^\\w[0-9.]?+\\.[0-9]$";
    private static final String FILE = "^\\w+[a-zA-Z0-9._%+-]$";
    //check category input string
    public static String checkInputName() {
        Scanner in = new Scanner(System.in);
        //loop until user input correct
        while (true) {
            String result = in.nextLine().trim();
            if (result.isEmpty()) {
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            } else if (result.length() >= 1 && !result.contains(" ") && result.matches(NAME)) {
                return result;
            } else {
                System.out.println("Wrong input format! The name must have at least a string,");
                System.out.println("can only contain words with no space");
                System.out.print("Enter again: ");
            }
        }
    }
    

    public static String checkInputID() {
        while (true) {
            String result = checkInputString();
            //check user input ID valid
            if (result.isEmpty()) {
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            } else if (result.length() >= 1 && !result.contains(" ") && result.matches(ID)) {
                return result;
            } else {
                System.out.println("Invalid ID format. ID number must be between 3 numbers and no space.");
                System.out.print("Enter again: ");
            }
        }
    }
    
    public static String checkInputString() {
        Scanner in = new Scanner(System.in);
        //loop until user input correct
        while (true) {
            String result = in.nextLine().trim();
            if (result.isEmpty()) {
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            } else return result;
        }
    }

    //check price if number or not
    public static String checkInputPrice() {
        while (true) {
            String result = checkInputString();
            //check user input price valid
            if (result.matches(NUMBER)||result.matches(PRICE)) {
                return result;
            } else {
                System.out.print("Invalid phone format. Price can only contain number >0. Enter again: ");
            }
        }
    }

    public static String checkInputPrice2() {
        Scanner in = new Scanner(System.in);
        while (true) {
            String result = in.nextLine();
            if (result.isEmpty()) {
                return null;
            }
            //check user input price valid
            if (result.matches(NUMBER)||result.matches(PRICE)) {
                return result;
            } else
                System.out.print("Invalid phone format. Price can only contain number >0. Enter again: ");
        }
    }

     //check price if number or not
    public static String checkInputQuantity() {
        while (true) {
            String result = checkInputString();
            //check user input price valid
            if (result.matches(NUMBER)) {
                return result;
            } else {
                System.out.print("Invalid phone format. Quantity can only contain natural number >0 . Enter again: ");
            }
        }
    }

    public static String checkInputQuantity2() {
        Scanner in = new Scanner(System.in);
        while (true) {
            String result = in.nextLine();
            if (result.isEmpty()) {
                return null;
            }
            //check user input price valid
            if (result.matches(NUMBER)) {
                return result;
            } else
                System.out.print("Invalid phone format. Quantity can only contain natural number >0. Enter again: ");
        }
    }


    // check user input yes/no
    public static boolean checkInputYN() {
        //System.out.print("Do you want to continue? (Y/N): ");
        String userChoice = null;
        boolean choice = false;
        Scanner sc = new Scanner(System.in);
        do {
            userChoice = sc.nextLine().toUpperCase();
            if (userChoice.equals("N")) {
                choice = false;
            } else if (userChoice.equals("Y")) {
                choice = true;
            } else {
                System.out.println("Must be Y or N");
            }
        } while (!"N".equals(userChoice) && !"Y".equals(userChoice));
        return choice;
    }

    // check category existed
    public static boolean checkCategoryNameExisted(ArrayList<Category> list, String CateName) {
        for (Category category : list) {
            if (CateName.equals(category.getCateName())) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean checkCategoryIDExisted(ArrayList<Category> list, String CateID) {
        for (Category category : list) {
            if (CateID.equals(category.getCateID())) {
                return false;
            }
        }
        return true;
    }

    // check catagory existed
    public static int checkCategoryIDExisted2(ArrayList<Category> list, String CategoryID) {
        for (Category category : list) {
            if (CategoryID.equals(category.getCateID())) {
                return list.indexOf(category);
            }
        }
        return -1;
    }

    public static String checkInputCateID2() {
        while (true) {
            String result = checkInputString();
            //check input update cateID
            if (result.length() >= 1 && !result.contains(" ") && result.matches(ID)) {
                return result;
            } else {
                System.out.println("Invalid Category ID format. Category ID number must be between 3 numbers and no space.");
                System.out.print("Enter again: ");
            }
        }
    }

// ------------------
// product
// ------------------
    // check product existed
    public static boolean checkProductNameExisted(ArrayList<Product> list, String CateName) {
        for (Product product : list) {
            if (CateName.equals(product.getProductName())) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean checkProductIDExisted(ArrayList<Product> list, String ProID) {
        for (Product product : list) {
            if (ProID.equals(product.getProductID())) {
                return false;
            }
        }
        return true;
    }

    // check catagory existed
    public static int checkProductIDExisted2(ArrayList<Product> list, String CategoryID) {
        for (Product product : list) {
            if (CategoryID.equals(product.getProductID())) {
                return list.indexOf(product);
            }
        }
        return -1;
    }

    public static String checkInputProductID2() {
        while (true) {
            String result = checkInputString();
            //check input update cateID
            if (result.length() >= 1 && !result.contains(" ") && result.matches(ID)) {
                return result;
            } else {
                System.out.println("Invalid ID format. Product ID number must be between 3 numbers and no space.");
                System.out.print("Enter again: ");
            }
        }
    }
// ------------------
// file
// ------------------
    public static String checkInputFile() {
        Scanner in = new Scanner(System.in);
        //loop until user input correct
        while (true) {
            String result = in.nextLine().trim();
            if (result.isEmpty()) {
                System.err.println("Not empty");
                System.out.print("Enter again: ");
            } else if (result.length() >= 1 && !result.contains(" ") && result.matches(FILE)) {
                return result;
            } else {
                System.out.println("Wrong input format! The file name must have at least 1 string, no space.");
                System.out.println("can only accept <name>.txt fortmat");
                System.out.print("Enter again: ");
            }
        }
    }
}
