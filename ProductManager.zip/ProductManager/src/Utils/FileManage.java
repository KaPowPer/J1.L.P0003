package Utils;

import DTO.Category;
import DTO.Product;
import DAO.CategoryList;
import DAO.ProductList;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;

public class FileManage {
    private static String filenamec = "D:\\Drive-Quang\\FPT tings\\2020-course3\\LABjava\\Lab3\\category.txt";
    private static String filenamep = "D:\\Drive-Quang\\FPT tings\\2020-course3\\LABjava\\Lab3\\product.txt";
    private static String filename;
    CategoryList Clist = new CategoryList();
    ProductList Plist = new ProductList();
    
    public void SelectFile() {
        while (true) {
            
            //cateFile
            while (true) {
                System.out.println("Default category file: " + filenamec);
                System.out.print("Enter a file or making a new one: (name only): ");
                filename = PValid.checkInputFile();
                //read and print CateFile
                readFromCustomFileNameTo(filenamec);
                System.out.println("File loaded.");
                loadCategory();
                Clist.printFile();
                break;
            }
            
            //proFile
            while (true) {
                System.out.print("Default product file: " + filenamep);
                System.out.print("Enter a file or making a new one: (name only): ");
                filename = PValid.checkInputFile();
                //read and print proFile
                readFromCustomFileNameTo(filenamep); 
                System.out.println("File loaded");
                loadProduct();
                Plist.printFile();
                break;
            }
            //print file
            System.out.println("Both category file and product file loaded.");
            System.out.println();
        }
    }
    
    // read file to return list of product
    public static ArrayList<Product> loadProduct() {
        FileReader f = null;
        BufferedReader rf = null;
        ArrayList<Product> list = new ArrayList<>();
        File f1 = new File(filenamep);
        if (!f1.exists()) {
            try {
                f1.createNewFile();
                System.out.println(" Create File: " + f1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            f = new FileReader(filenamep);
            rf = new BufferedReader(f);

            while (rf.ready()) {
                String s = rf.readLine();
                String[] arr = s.split(",");

                Product temp = new Product(arr[0], arr[1], arr[2], arr[3], arr[4]);
                list.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("The file is not existed! Please save the data to file or create \"product.txt\" in project folder!");
        } finally {
            try {
                if (f != null)
                    f.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    // save to file
    public static void writeProduct(ArrayList<Product> list) {
        // check null list
        if (list == null || list.isEmpty()) return;

        PrintWriter w = null;

        try {
            w = new PrintWriter(filenamep);
            for (Product product : list) {
                w.println(product);
                w.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("The file is not existed! Please save the data to file or create \"product.txt\" in project folder!");
        } finally {
            try {
                if (w != null)
                    w.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // read file to return list of category
    public static ArrayList<Category> loadCategory() {
        FileReader f = null;
        BufferedReader rf = null;
        ArrayList<Category> list = new ArrayList<>();
        File f1 = new File(filenamec);
        if (!f1.exists()) {
            try {
                f1.createNewFile();
                System.out.println("Create File: " + f1);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            f = new FileReader(filenamec);
            rf = new BufferedReader(f);

            while (rf.ready()) {
                String s = rf.readLine();
                String[] arr = s.split(",");

                Category temp = new Category(arr[0], arr[1]);
                list.add(temp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("The file is not existed! Please save the data to file or create \"category.txt\" in project folder!");
        } finally {
            try {
                if (f != null)
                    f.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    // save to file
    public static void writeCategory(ArrayList<Category> list) {
        // check null list
        if (list == null || list.isEmpty()) return;

        PrintWriter w = null;

        try {
            w = new PrintWriter(filenamec);
            for (Category category : list) {
                w.println(category);
                w.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("The file is not existed! Please save the data to file or create \"category.txt\" in project folder!");
        } finally {
            try {
                if (w != null)
                    w.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public static ArrayList<Product> readFromCustomFileNameTo(String filelocate){
        filename = String.format("D:\\Drive-Quang\\FPT tings\\2020-course3\\LABjava\\Lab3\\%s.txt",filename);
        filelocate = filename;
        return null;
    }
}