package Manager;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

public class ProMenu extends Vector<String> {
    public ProMenu(){
        super();
    }
    public Integer getUserChoice(){
        Scanner sc = new Scanner(System.in);
        Integer choice = 0;
        try{
            System.out.print("Input your choice here:  ");
            choice = sc.nextInt();
        }catch(InputMismatchException e){
            System.out.print("");
        }
        return choice;
    }
}