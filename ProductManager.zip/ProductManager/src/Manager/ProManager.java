package Manager;


import DAO.CategoryList;
import DAO.ProductList;
import Utils.FileManage;

public class ProManager {
    public static void main(String[] args) {
        CategoryList Clist = new CategoryList();
        ProductList Plist = new ProductList();
        ProMenu menu = new ProMenu();
        FileManage file = new FileManage();
        
        file.SelectFile();
        
        menu.add("1. Add new category");
        menu.add("2. Update category");
        menu.add("3. Delete category");
        menu.add("4. Add new product");
        menu.add("5. Update product");
        menu.add("6. Delete product");
        menu.add("7. Order product");
        menu.add("8. Show order list report");
        menu.add("Others. Quit Program");
        int userChoice;
        do {
            System.out.println("\n---PRODUCT MANAGEMENT---");
            for (Object str : menu) {
                System.out.println(str);
            }
            userChoice = menu.getUserChoice();
            switch (userChoice) {
                case 1: {
                    Clist.AddCategory();
                    System.out.println();
                    break;
                }
                case 2: {
                    Clist.UpdateCategory();
                    System.out.println();
                    break;
                }
                case 3: {
                    Clist.DeleteCategory();
                    System.out.println();
                    break;
                }
                case 4: {
                    Plist.AddProduct();
                    System.out.println();
                    break;
                }
                case 5: {
                    Plist.UpdateProduct();
                    System.out.println();
                    break;
                }
                case 6: {
                    Plist.DeleteProduct();
                    System.out.println();
                    break;
                }
                case 7: {
                    Plist.AddOrder();
                    System.out.println();
                    break;
                }
                case 8: {
                    Plist.ShowOrder();
                    System.out.println();
                    break;
                }
                case 9: {
                    Clist.printFile();
                    System.out.println();
                    break;
                }
                default:
                    System.out.println("Application Exited");
            }
        }while(userChoice >= 1 && userChoice <= 8);
    }
}
