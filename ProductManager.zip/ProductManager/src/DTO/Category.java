package DTO;

import java.util.Comparator;

public class Category{
    private String CateID;
    private String CateName;

    public Category(String CateID, String CateName) {
        this.CateID = CateID;
        this.CateName = CateName;
    }

    public String getCateName() {
        return CateName;
    }

    public void setCateName(String CateName) {
        this.CateName = CateName;
    }

    public String getCateID() {
        return CateID;
    }

    public void setCateID(String CateID) {
        this.CateID = CateID;
    }

    @Override
    public String toString() {
        return CateID + "," + CateName;
    }
    
    public static Comparator<Category> FirstCateID = new Comparator<Category>() {

        public int compare(Category c1, Category c2) {
            String CateID1 = c1.getCateID();
            String CateID2 = c2.getCateID();

            //ascending order
            return CateID1.compareTo(CateID2);

            //descending order
            //return CateID2.compareTo(CateID1);
        }
    };

}
    