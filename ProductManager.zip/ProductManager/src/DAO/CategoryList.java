package DAO;

import DTO.Category;
import Utils.FileManage;
import Utils.PValid;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
public class CategoryList{

    private ArrayList<Category> list = new ArrayList<>();
    private ArrayList<Category> tempList = new ArrayList<>();
    public CategoryList() {
        super();
    }
    // create category
    public void AddCategory() {
        list = FileManage.loadCategory();
        tempList = list;
        while (true) {
            String CategoryID;
            String CategoryName;
            
            //cateID
            while (true) {
                System.out.print("Enter a Category ID: ");
                CategoryID = PValid.checkInputID();
                // check exist CateID
                if (!PValid.checkCategoryIDExisted(list, CategoryID)) {
                    System.out.println("Category ID existed! Enter again");
                } else {
                    break;
                }
            }
            
            //cateName
            while (true) {
                System.out.print("Enter a Category name: ");
                CategoryName = PValid.checkInputName();
                // check exist CateName
                if (!PValid.checkCategoryNameExisted(list, CategoryName)) {
                    System.out.println("Category name existed! Enter again");
                } else {
                    break;
                }
            }
            
            // save to file
            list.add(new Category(CategoryID,CategoryName));
            FileManage.writeCategory(list);
            System.out.println("Added");
            
            //Yes no option
            System.out.print("Continue to create category? (y/n)");
            if (!PValid.checkInputYN()) {
                return;
            } else FileManage.writeCategory(list);
            System.out.println();
        }
    }
    
    public void UpdateCategory() {
        Scanner sc = new Scanner(System.in);
        list = FileManage.loadCategory();
        boolean confirmed;
        int pos = -1;
        do {
            //Category ID
            System.out.print("Enter Category ID: ");
            String CategoryID = PValid.checkInputID();
            pos = PValid.checkCategoryIDExisted2(list, CategoryID);
            // check existed
            if (pos < 0) {
                System.out.println("Category ID does not existed!");
                System.out.print("Do you want to try again? (y/n): ");
                if (!PValid.checkInputYN()) {
                    return;
                }
            }
            else {
                System.out.print("Enter new Category ID: ");
                String CateID = sc.nextLine();
                if (!CateID.isEmpty())
                    list.get(pos).setCateID(CateID);

                System.out.print("Enter new Category Name: ");
                String CateName = sc.nextLine();
                if (!CateName.isEmpty())
                    list.get(pos).setCateName(CateName);
                
                // save to file
                FileManage.writeCategory(list);
                System.out.println("Added");
                System.out.println("Update successful");
                System.out.println("Update data should be saved!");
            }
            System.out.print("Continue to update a category? (y/n): ");
            confirmed = PValid.checkInputYN();
            if (!confirmed) {
                return;
            }
        } while (true);
    }

    // delete category
    public void DeleteCategory() {
        list = FileManage.loadCategory();
        int pos = -1;
        while (true) {
            // Checking CateID
            System.out.print("Enter Category ID: ");
            String CategoryID = PValid.checkInputID();
            pos = PValid.checkCategoryIDExisted2(list, CategoryID);
            // check CateID is correct

            if (pos < 0 || PValid.checkCategoryIDExisted2(list, CategoryID) < 0) {
                System.out.println("Category ID is not existed or wrong!");
                System.out.print("Do you want to try again? (y/n): ");
                if (!PValid.checkInputYN()) {
                    return;
                }
            } else {
                // remove category
                System.out.println("Category ID " + list.get(pos).getCateID() + " has been removed!");
                list.remove(pos);
                FileManage.writeCategory(list);
            }

            System.out.print("Continue to remove a catagory? (y/n): ");
            if (!PValid.checkInputYN()) {
                return;
            }
        }
    }
    
    // save to file
    public void saveFile() {
        if (list.isEmpty()) {
            System.out.println("Nothing to save!");
            return;
        }
        FileManage.writeCategory(list);
        System.out.println("Saved");
    }

    // print all list from file
    public void printFile() {
        int count = 0;
        list = FileManage.loadCategory();
        Collections.sort(list, Category.FirstCateID);
        System.out.println("The list show in order: CategoryID, CategoryName");
        for (Category category : list) {
            count++;
            System.out.print(count + ". ");
            System.out.println(category);
        }
    }
}