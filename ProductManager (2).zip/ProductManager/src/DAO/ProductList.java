package DAO;

import DTO.Category;
import DTO.Product;
import Utils.FileManage;
import Utils.PValid;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ProductList{
    private ArrayList<Category> clist = new ArrayList<>();
    private ArrayList<Category> ctempList = new ArrayList<>();
    private ArrayList<Product> list = new ArrayList<>();
    private ArrayList<Product> tempList = new ArrayList<>();
    public ProductList() {
        super();
    }
    public void AddProduct(){
        list = FileManage.loadProduct();
        tempList = list;
        clist = FileManage.loadCategory();
        ctempList = clist;
        while (true) {
            String ProductID;
            String ProductName;
            String Price;
            String Quantity;
            String CategoryID;  
            
            //ProductID
            while (true) {
                System.out.print("Enter a Product ID: ");
                ProductID = PValid.checkInputID();
                // check exist ProID
                if (!PValid.checkProductIDExisted(list, ProductID)) {
                    System.out.println("Product ID existed! Enter again");
                } else {
                    break;
                }
            }
            //ProductName
            while (true) {
                System.out.print("Enter a Product Name: ");
                ProductName = PValid.checkInputName();
                // check exist ProName
                //if (!PValid.checkProductNameExisted(list, ProductName)) {
                //    System.out.println("Product name existed! Enter again");
                //} else {
                    break;
                //}
            }
            //price
                System.out.print("Enter a Product Price: ");
                Price = PValid.checkInputPrice();
            //quantity
                System.out.print("Enter a Product quantity: ");
                Quantity = PValid.checkInputQuantity();
            //cateID
            while (true) {
                System.out.print("Enter a Category ID already exist: ");
                CategoryID = PValid.checkInputID();
                // check exist CateID
                if (PValid.checkCategoryIDExisted(clist, CategoryID)) {
                    System.out.println("Category ID doesnt existed! Enter again");
                } else {
                    break;
                }
            }
            
            // save to file
            list.add(new Product(ProductID,ProductName,Price,Quantity,CategoryID));
            FileManage.writeProduct(list);
            System.out.println("Added");
            
            //Yes no option
            System.out.print("Continue to create product? (y/n)");
            if (!PValid.checkInputYN()) {
                return;
            } else FileManage.writeProduct(list);
            System.out.println();
        }
    }


    public void UpdateProduct() {
        Scanner sc = new Scanner(System.in);
        list = FileManage.loadProduct();
        clist = FileManage.loadCategory();
        boolean confirmed;
        int pos = -1;
        do {
            //Category ID select
            System.out.print("Enter Product ID: ");
            String ProductID = PValid.checkInputID();
            pos = PValid.checkProductIDExisted2(list, ProductID);
            // if not existed
            if (pos < 0) {
                System.out.println("Product ID does not exist!");
                System.out.print("Do you want to try again? (y/n): ");
                if (!PValid.checkInputYN()) {
                    return;
                }
            }
            else {
                //ID
                System.out.print("Enter new Product ID: ");
                String ProID = sc.nextLine();
                if (!ProID.isEmpty())
                    list.get(pos).setProductID(ProID);
                
                //Name
                System.out.print("Enter new Product Name: ");
                String ProName = sc.nextLine();
                if (!ProName.isEmpty())
                    list.get(pos).setProductName(ProName);
                
                //Price
                System.out.print("Enter new Product price: ");
                String price = PValid.checkInputPrice2();
                if (price != null) list.get(pos).setPrice(price);
                
                //Quantity
                System.out.print("Enter new Product quantity: ");
                String quantity = PValid.checkInputQuantity2();
                if (quantity != null) list.get(pos).setPrice(quantity);
                
                //Category
                while (true) {
                    System.out.print("Enter new Product Category ID: ");
                    String CategoryID = sc.nextLine();
                    if (!CategoryID.isEmpty()){
                        list.get(pos).setCategoryID(CategoryID);
                        break;
                    }
                    else {CategoryID = PValid.checkInputID();
                        // check exist CateID
                        if (PValid.checkCategoryIDExisted(clist, CategoryID)) {
                            System.out.println("Category ID doesnt existed! Enter again");
                        } else {
                            break;
                        }
                    }
                }
                
                // save to file
                FileManage.writeProduct(list);
                System.out.println("Added");
                System.out.println("Update successful");
                System.out.println("Update data should be saved!");
            }
            System.out.print("Continue to update a product? (y/n): ");
            confirmed = PValid.checkInputYN();
            if (!confirmed) {
                return;
            }
        } while (true);
    }

    // delete category
    public void DeleteProduct() {
        list = FileManage.loadProduct();
        int pos = -1;
        while (true) {
            // Checking CateID
            System.out.print("Enter Product ID: ");
            String ProductID = PValid.checkInputID();
            pos = PValid.checkProductIDExisted2(list, ProductID);
            // check CateID is correct

            if (pos < 0 || PValid.checkProductIDExisted2(list, ProductID) < 0) {
                System.out.println("Product ID is not existed or wrong!");
                System.out.print("Do you want to try again? (y/n): ");
                if (!PValid.checkInputYN()) {
                    return;
                }
            } else {
                // remove category
                System.out.println("Product ID " + list.get(pos).getProductID() + " has been removed!");
                list.remove(pos);
                FileManage.writeProduct(list);
            }

            System.out.print("Continue to remove a catagory? (y/n): ");
            if (!PValid.checkInputYN()) {
                return;
            }
        }
    }
    
    public void AddOrder() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void ShowOrder() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
        // save to file
    public void saveFile() {
        if (list.isEmpty()) {
            System.out.println("Nothing to save!");
            return;
        }
        FileManage.writeProduct(list);
        System.out.println("Saved");
    }

    // print all list from file
    public void printFile() {
        int count = 0;
        list = FileManage.loadProduct();
        Collections.sort(list, Product.FirstProID);
        System.out.println("The list show in order: ProductID, ProductName, Price($), Quantity, CateID");
        for (Product product : list) {
            count++;
            System.out.print(count + ". ");
            System.out.println(product);
        }
        System.out.println();
    }

    public void Order() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
