package DAO;

import DTO.Category;
import DTO.Order;
import DTO.Product;
import Utils.FileManage;
import Utils.PValid;
import java.util.ArrayList;
import java.util.Hashtable;

public class OrderList {
    private ArrayList<Category> clist = new ArrayList<>();
    private ArrayList<Category> ctempList = new ArrayList<>();
    private ArrayList<Product> list = new ArrayList<>();
    private ArrayList<Product> tempList = new ArrayList<>();
    ProductList Plist = new ProductList();
    public OrderList() {
        super();
    }
    public void Order(ArrayList<Product> PList, Hashtable<String, ArrayList<Order>> ht){
        list = FileManage.loadProduct();
        clist = FileManage.loadCategory();
        int pos = -1;
        if(PList.isEmpty()) {
            System.out.println("Sold out!\n");
            return;
        }
        ArrayList<Order> OList=new ArrayList<>();
        while(true) {
            Plist.printFile();
            //Category ID select
            System.out.print("Choose a product ID: ");
            String ProductID = PValid.checkInputID();
            pos = PValid.checkProductIDExisted2(list, ProductID);
            // if not existed
            if (pos < 0) {
                System.out.println("Product ID does not exist!");
                System.out.print("Do you want to try again? (y/n): ");
                if (!PValid.checkInputYN()) {
                    return;
                }
            }
            
            //select
            System.out.println("You selected: " +list.get(pos).getProductID()+","+list.get(pos).getProductName());
            while(true) {
                System.out.print("Enter quantity: ");
                String quantity = PValid.checkInputQuantity();
                //check quantity
                int quant = Integer.parseInt(quantity);
                String tquantp=list.get(pos).getQuantity();
                int quantp = Integer.parseInt(tquantp);
                if (quant>quantp){
                    
                }
            }
            
            
            
            
            
            
            if(!Val.checkItemExist(OList, pro.getProductID(), pro.getProductName())) {
                updateOrder(OList,pro.getProductID(),pro.getProductName(),quantity);
            }
            else{
                OList.add(new Order(pro.getProductID(),pro.getProductName(),quantity,pro.getPrice()));
            }
            delete(PList, pro); 
            if(PList.isEmpty()) {
                System.err.println("Sold Out!");
                displayListOrder(OList);
                System.out.print("Enter customer name:");
                String name=Val.checkInputString();
                ht.put(name, OList);
                System.err.println("Add successfull");
                return;
            }
            if(Val.checkInputYN()) {
                displayListOrder(OList);
                System.out.print("Enter name: ");
                String name=Val.checkInputString();
                ht.put(name,OList);
                System.err.println("Add successfull");
                return;
            }
        
        }
    }
    
     static Product getProByItem(ArrayList<Product> PList, int item) {
        int Item = 1;
        for (Product pro : PList) {
            if (pro.getQuantity() != 0) {
                Item++;
            }
            if (Item - 1 == item) {
                return pro;
            }
        }
        return null;
    }
     
     public static void updateOrder(ArrayList<Order> OList, String PID, String PN, int quantity) {
         for(Order or:OList) {
             if(or.getProductID().equalsIgnoreCase(PID)
             && or.getProductName().equalsIgnoreCase(PN))
             { or.setQuantity(or.getQuantity()+quantity);
             return;}
         }
     }
     
     public static void delete(ArrayList<Product> PList, Product item) {
         for(Product pro:PList) {
             if(pro.getProductID().equals(item.getProductID()) 
                     && item.getQuantity()==0) {
                 PList.remove(pro);
                 return;
             }
         }
     }
     
    public static void displayListOrder(ArrayList<Order> OList) {
        double total = 0;
        int Itemp = 1;
        System.out.println("+-----+--------------------+----------+-------+--------+");
        System.out.printf("|%-5s|%20s|%10s|%7s|%8s|\n", "No.", "Product", "Quantity", "Price", "Amount");
        System.out.println("+-----+--------------------+----------+-------+--------+");

        for (Order or : OList) {
            System.out.printf("|%5s|%-20s|%10d|%6.0f$|%7.0f$|\n", Itemp++, or.getProductName(),
                    or.getQuantity(), or.getPrice(),
                    or.getPrice() * or.getQuantity());
            total += or.getPrice() * or.getQuantity();
        }
        System.out.println("+-----+--------------------+----------+-------+--------+");
        System.out.printf("|\t\t\t\t\tTotal |%7.0f$|\n", total);
        System.out.println("+-----+--------------------+----------+-------+--------+");
    }
}
