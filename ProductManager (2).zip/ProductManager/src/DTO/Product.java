package DTO;

import java.util.Comparator;

public class Product{
    private String ProductID;
    private String ProductName;
    private String Price;
    private String Quantity;
    private String CategoryID;

    public Product(String ProductID, String ProductName, String Price, String Quantity, String CategoryID) {
        this.ProductID = ProductID;
        this.ProductName = ProductName;
        this.Price = Price;
        this.Quantity = Quantity;
        this.CategoryID = CategoryID;
    }

    public String getProductID() {
        return ProductID;
    }

    public void setProductID(String ProductID) {
        this.ProductID = ProductID;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }

    public String getCategoryID() {
        return CategoryID;
    }

    public void setCategoryID(String CategoryID) {
        this.CategoryID = CategoryID;
    }

    public static Comparator<Product> getFirstProID() {
        return FirstProID;
    }

    public static void setFirstProID(Comparator<Product> FirstProID) {
        Product.FirstProID = FirstProID;
    }

    @Override
    public String toString() {
        return ProductID + "," + ProductName + "," + Price + "," + Quantity + "," + CategoryID;
    }

    public static Comparator<Product> FirstProID = new Comparator<Product>() {
        public int compare(Product c1, Product c2) {
            String ProductID1 = c1.getProductID();
            String ProductID2 = c2.getProductID();

            //ascending order
            return ProductID1.compareTo(ProductID2);

            //descending order
            //return CateID2.compareTo(CateID1);
        }
    };

}