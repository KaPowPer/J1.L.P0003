package DTO;

import java.util.Comparator;

public class Order{
    private String ProductID;
    private String ProductName;
    private String Price;
    private String Quantity;

    public Order(String ProductID, String ProductName, String Price, String Quantity) {
        this.ProductID = ProductID;
        this.ProductName = ProductName;
        this.Price = Price;
        this.Quantity = Quantity;
    }

    public String getProductID() {
        return ProductID;
    }

    public void setProductID(String ProductID) {
        this.ProductID = ProductID;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String ProductName) {
        this.ProductName = ProductName;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String Quantity) {
        this.Quantity = Quantity;
    }

    @Override
    public String toString() {
        return ProductID + "," + ProductName + "," + Price + "," + Quantity;
    }
    
    

}
